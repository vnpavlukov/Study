let admin = ''
let name = 'Василий'

admin = name;
console.log(admin);