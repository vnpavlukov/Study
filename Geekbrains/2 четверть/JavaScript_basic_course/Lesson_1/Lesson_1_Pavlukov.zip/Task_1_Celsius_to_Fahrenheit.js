let Celsius = prompt('Give me the Celsius and I will say you Fahrenheit:');


function CelsToFahr(numb) {
    return (9/5) * numb + 32;
};

alert(CelsToFahr(Celsius))
